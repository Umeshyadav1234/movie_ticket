package routes

import (
	"MTBS/controllers"
	middleware "MTBS/login"

	"github.com/gin-gonic/gin"
)

func SettingUpRoutes(r *gin.Engine) *gin.Engine {

	register := r.Group("/register")
	{
		register.POST("/user", controllers.RegisterCustomer)
		register.POST("/admin", controllers.RegisterAdmin)

	}
	login := r.Group("/login")
	{
		login.POST("/user", middleware.LoginUser)
		login.POST("/Admin", middleware.LoginAdmin)
	}

	return r

}
